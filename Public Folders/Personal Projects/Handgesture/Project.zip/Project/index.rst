.. HandGestureRecognition documentation master file, created by
   sphinx-quickstart on Sun Oct  6 17:46:51 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to HandGestureRecognition's documentation!
==================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: FlaskDeploymentHandGesture
   :members:

.. automodule:: HandGesture
   :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
